
    WCT.loadSuites([
      'basic.html',
      'a11y.html'
    ]);
  