

    scope = document.querySelector('template[is=auto-binding]');

    scope.pastries = [
      'Apple fritter',
      'Croissant',
      'Donut',
      'Financier',
      'Jello',
      'Madeleine',
      'Pound cake',
      'Pretzel',
      'Sfogliatelle'
    ];

  