
    WCT.loadSuites([
      // 'basic.html'
    ]);
  