core-animation
==============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-animation) for more information.
