

  CoreStyle.g.theme = {
    colorOne: '#abcdef',
    colorTwo: '#123456',
    colorThree: '#224433'
  }
