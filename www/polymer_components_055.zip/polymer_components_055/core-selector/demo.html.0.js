
      Polymer('selector-examples', {
        ready: function() {
          this.multiSelected = [1, 3];
          this.color = 'green';
        }
      });
    