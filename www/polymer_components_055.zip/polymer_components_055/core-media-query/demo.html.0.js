
      Polymer('match-example', {
        query: 'min-width: 600px'
      });
    