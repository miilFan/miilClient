
    runTests('tests.json');
  