paper-dialog
===================

See the [component page](http://www.polymer-project.org/docs/elements/paper-elements.html#paper-dialog) for more information.
