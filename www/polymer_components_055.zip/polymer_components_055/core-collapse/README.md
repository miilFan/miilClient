core-collapse
=============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-collapse) for more information.
