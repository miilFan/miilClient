core-item
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-item) for more information.
