
    Polymer({
      resizerIsPeer: true     
    });
  